package dashboard.main.controller;

import dashboard.main.model.InventoryEntity;
import dashboard.main.repository.InventoryRepository;
import dashboard.main.service.InventoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Controller
public class AppController {

    @Autowired
    private InventoryRepository inventoryRepository;

    @InitBinder
    public void initBinder(WebDataBinder binder) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        dateFormat.setLenient(false);

        // true passed to CustomDateEditor constructor means convert empty String to null
        binder.registerCustomEditor(Date.class, "datePulledOut", new CustomDateEditor(dateFormat, true));
    }

    @GetMapping("/inventory")
    public List<InventoryEntity> listInventory() {
        return inventoryRepository.findAll();
    }

    @GetMapping(value = "/queries")
    @ResponseBody
    public List<InventoryEntity> getResult() {
        return inventoryRepository.findAll();
    }

    @Autowired
    InventoryService inventoryService;

    @GetMapping(value = {"/tabEdit", "/tabEdit/{terminal_id}"})
    public String tabEditForm(Model model, @PathVariable(required = false, name = "terminal_id") String terminalId) {
        if (terminalId != null) {
            model.addAttribute("inventory", inventoryService.findOne(terminalId));
        } else {
            model.addAttribute("inventory", new InventoryEntity());
        }
        return "tabEdit";
    }

    @PostMapping(value = {"/tabEdit"})
    public ResponseEntity<?> tabEdit(InventoryEntity entity) {
        inventoryService.save(entity);
        return new ResponseEntity<>("Changes saved.", HttpStatus.OK);
    }

    @PostMapping(value = {"/decommission/{terminal_id}"})
    @ResponseBody
    public ResponseEntity<?> decommission(@PathVariable(name = "terminal_id") String terminalId) {
        if (inventoryService.decommission(terminalId))
            return new ResponseEntity<>("Machine Decommissioned.", HttpStatus.OK);
        return new ResponseEntity<>("Record not found.", HttpStatus.NOT_FOUND);
    }

    @PostMapping(value = {"/tabAdd"})
    public String tabAdd(Model model, InventoryEntity entity) {
        inventoryService.save(entity);
        model.addAttribute("inventory", entity);
        return "inventory";
    }
}
